// ----------------------------------------------
// These are the only libraries that can be
// used. Under no circumstances can additional
// libraries be included
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include "shell.h"

// --------------------------------------------
// Currently only two builtin commands for this
// assignment exist, however in future, more could
// be added to the builtin command array.
// --------------------------------------------
const char* valid_builtin_commands[] = {"cd", "exit", NULL};

void parse(char* line, command_t* p_cmd){
  int numOfChars = 0;
  int numOfSpacesToRemove = 0; //the number of trailing spaces in the char* line
  for(int i = 0;line[i]!='\0';i=i+1){//loops through the char* line and counts the number of chars in the char* line
    numOfChars = i + 1;
  }
  while(*(line+numOfChars -1) == ' '){
      numOfSpacesToRemove = numOfSpacesToRemove + 1;
      numOfChars = numOfChars - 1;//sets numOfChars to the correct number of chars minus the spaces at the end
  }
  char * lineMinusSpaces = (char*)malloc(numOfChars);
  //printf("the size of the new string is %d\n",numOfChars);
  for(int i = 0; i < numOfChars;i=i+1){//assigns line to lineMinusSpaces without the trailing spaces
    *(lineMinusSpaces + i) = line[i];
  }
  lineMinusSpaces[numOfChars]= '\0';//terminates the string without spaces
  //todo here I have a line with no trailling spaces
  //I can count the number of spaces to get the number of arguments here\/
  int numOfSpaces = 0;

  for(int i = 0;lineMinusSpaces[i]!='\0';i=i+1){//loops through char* line and counts the number of spaces in the char* line
    if(lineMinusSpaces[i]==' '){
      numOfSpaces = numOfSpaces + 1;
    }
  }
  int locationOfSpaces[numOfSpaces+2];
  locationOfSpaces[0] = -1;//assigns zero as the first space so we can take a substring from first_location +1 to next_location -1 (inclusive)
  locationOfSpaces[numOfSpaces+1] = numOfChars-1;
  int spaceCounter = 1;
  for(int i = 0;lineMinusSpaces[i]!='\0';i=i+1){//loops through char* line again but this time it remembers where each space was located.
    if(lineMinusSpaces[i]==' '){
      locationOfSpaces[spaceCounter] = i;
      spaceCounter = spaceCounter + 1;
    }
  }
   //this loops prints the locations of valid spaces within line including a -1 first element, and a last element (sizeof line) as an implict space
  for(int i = 0; i < numOfSpaces+2;i= i + 1){
    printf("\t\t%d\n",locationOfSpaces[i] );
  }
  //
  //  AT THIS POINT ARGC IS THE ONLY THING CALCULATED
  char ** argvTemp;//numOfSpaces + 1 is the same as argc
  argvTemp = (char**) malloc(sizeof(numOfSpaces+1));
  for(int i = 0;i<=numOfSpaces;i=i+1){//this loop is trying to assign the line elements to their position in argv
      int sizeOfArgument = (locationOfSpaces[i+1]-locationOfSpaces[i])- 1;
      argvTemp[i] = (char*) malloc(sizeof(sizeOfArgument+1));
      int counter = 0;
      for(int z = locationOfSpaces[i]+1;z<locationOfSpaces[i+1];z = z +1){
        *((*(argvTemp + i))+counter) = lineMinusSpaces[z];
        // printf("I sure hope this works: %c\n",lineMinusSpaces[z] );
        counter = counter +1;
      }
      *((*(argvTemp + i))+counter) = '\0';//terminates my strings
  }
  // printf("%s\n",lineMinusSpaces);//for some reason printing this line here allows line to be passed to main
   p_cmd->argv = argvTemp;
  p_cmd->argc = numOfSpaces+1;//assigns argc to be the number of spaces in the line plus one
  p_cmd->name = argvTemp[0];

}
int is_builtin(command_t* p_cmd){
  if(strEquals(p_cmd->name ,valid_builtin_commands[0]) ||strEquals(p_cmd->name ,valid_builtin_commands[1]) ){
    return 1;
  }
  return 0;
}
int do_builtin(command_t* p_cmd){
  int chdirVal;
	chdirVal = chdir(p_cmd->argv[1]);
	if(chdirVal == 0){
		return 1;
	}else{
		return 0;
	}

}
int find_fullpath(char* fullpath, command_t* p_cmd){
  char* path_env_variable;
  path_env_variable = getenv("PATH");
  // printf("PATH = %s\n", path_env_variable);
  struct stat buffer;
  int exists;
  // string that represents the fully qualified
  // path of a file or directory on the file system
  char* file_or_dir = p_cmd->argv[0];
  exists = stat(file_or_dir, &buffer);
  if (exists == 0 ) {
    printf("%s\n","dir Exists" );
  } else if ( exists == 0 ) {
    printf("%s\n","file Exists" );
  } else {
    printf("%s\n","file no exist" );
  }
}
// int execute(command_t* p_cmd);
// void cleanup(command_t* p_cmd);
int strEquals(const char *s, const char *t)//TODO make this methods an str equals method
{
	while (*s == *t && *s != '\0')
	{
		s++;
		t++;
	}
	if(*s == '\0' && *t == '\0'){
		return 1;
	}
	return 0;
}
